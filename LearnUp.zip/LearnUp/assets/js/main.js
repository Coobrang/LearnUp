// Mobile Menu
const menuBtn = document.querySelector('.menu-btn');
const mobileMenu = document.querySelector('.mobile-menu');

menuBtn.addEventListener('click', () => {
  menuBtn.classList.toggle('active');
  mobileMenu.classList.toggle('active');
  menuBtn.querySelector('i').classList.toggle('fa-bars');
  menuBtn.querySelector('i').classList.toggle('fa-times');
});

document.querySelectorAll('.submenu > a').forEach(item => {
  item.addEventListener('click', (e) => {
    e.preventDefault();
    const subMenu = item.nextElementSibling;
    subMenu.classList.toggle('active');
  });
});


// ScrollTop
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  var button = document.getElementById("goToTopBtn");
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    button.style.display = "block";
  } else {
    button.style.display = "none";
  }
}

document.getElementById("goToTopBtn").addEventListener("click", function() {
  scrollToTop(500);
});

function scrollToTop(scrollDuration) {
  var scrollStep = -window.scrollY / (scrollDuration / 15),
      scrollInterval = setInterval(function(){
      if ( window.scrollY != 0 ) {
          window.scrollBy( 0, scrollStep );
      }
      else clearInterval(scrollInterval); 
  },15);
}